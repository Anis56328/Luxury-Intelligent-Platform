#!/usr/bin/env bash
# Reconstruit données, analyses, figures, dashboard HTML et rapport PDF
set -e
cd "$(dirname "$0")/Python"
python3 01_build_dataset.py
python3 02_analysis.py
python3 03_build_dashboard.py
python3 04_build_report.py
